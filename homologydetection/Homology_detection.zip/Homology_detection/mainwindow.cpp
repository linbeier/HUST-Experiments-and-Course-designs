#include "mainwindow.h"
#include "ui_mainwindow.h"

//#include "iostream"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_choose1btn_clicked()
{

    file1_path=QFileDialog::getOpenFileName(NULL,"file choose",".",NULL);
    ui->textEdit->setText(file1_path);
}

void MainWindow::on_choose2btn_clicked()
{
    //不同的方式打开文件夹
    QDir dir;
    file2_path=QFileDialog::getExistingDirectory(NULL,"file fold open",".");
    dir.setPath(file2_path);
    QFileInfoList list=dir.entryInfoList();
    for(int i=0;i<list.size();i++){
        fileinfo[i]=list.at(i);
        ui->textEdit_2->setText(fileinfo[i].fileName());
    }
    listsize=list.size();
}


void MainWindow::on_comparebtn_clicked()
{
    QString filein="/Users/bin/Desktop/QT/homologydetection/00.c";
    commentdetect(file1_path,filein);
    for(int i=0;i<listsize;i++){
        QString fileout;
        QTextStream(&fileout)<<"/Users/bin/Desktop/QT/homologydetection/"<<i<<".c";
        commentdetect(fileinfo[i].fileName(),fileout);
    }
    for(int i=0;i<listsize;i++){
        QString fileout;
        QTextStream(&fileout)<<"/Users/bin/Desktop/QT/homologydetection/"<<i<<".c";
        compareline(filein,fileout,i);
    }
}

void MainWindow::commentdetect(QString filein_path,QString fileout_path){
    int delno,delno1,delno2;
    unsigned int delnum,delnum1,delnum2;
    bool isComment2match=1;
    QString file1line,comment1="//",comment2="/*",comment3="*/";
    QFile file1(filein_path);
    QFile file1a(fileout_path);
    file1.open(QIODevice::ReadOnly);
    file1a.open(QIODevice::WriteOnly);
    QTextStream in(&file1);
    QTextStream out(&file1a);

    while (!in.atEnd()) {
        file1line=in.readLine();
        //indexof return -1 if not found
        delno=file1line.indexOf(comment1);
        delno1=file1line.indexOf(comment2);
        delno2=file1line.indexOf(comment3);
        if(delno==-1)delno=0;
        if(delno1==-1)delno1=0;
        if(delno2==-1)delno2=0;
        delnum=file1line.length()-delno;
        delnum1=file1line.length()-delno1;
        delnum2=delno2;
        if(delno&&isComment2match){
            file1line.remove(delno,delnum);

        }
        else if(delno1&&isComment2match){
            file1line.remove(delno1,delnum1);
            isComment2match=0;
        }
        else if(delno2&&isComment2match==0){
            file1line.remove(0,delnum2);
            isComment2match=1;
        }
        else if(isComment2match==0){
            file1line.clear();
        }
        out<<file1line<<'\n';
    }

}

void MainWindow::compareline(QString file1_path,QString file2_path,int fileno){
    QString comparedtext;
    QString compare_a_line;
    bool times;
    float hit=0;
    float all=0;
    float rate;
    QFile file1(file1_path);
    file1.open(QIODevice::ReadOnly);
    QTextStream in(&file1);
    QFile file2(file2_path);
    file2.open(QIODevice::ReadOnly);
    QTextStream in2(&file2);

    comparedtext=in2.readAll();

    while (!in.atEnd())
    {
        compare_a_line=in.readLine();
        if(compare_a_line.trimmed()!=NULL)
        {
            times=comparedtext.contains(compare_a_line,Qt::CaseSensitive);

            if(times!=0)hit++;
            all++;
        }
    }
    rate=hit/all;
    QString rate1 = QString("%1").arg(rate);
    ui->resultshow->setText(fileno+":");
    ui->resultshow->setText(rate1+"\n");
}

void MainWindow::gettoken(){
    QString command1="gcc -E /Users/bin/Desktop/1.c";
    QString command2="gcc -E /Users/bin/Desktop/2.c";
    QProcess::execute(command1);
    QProcess::execute(command1);
}

void MainWindow::on_pushButton_clicked()
{

}
