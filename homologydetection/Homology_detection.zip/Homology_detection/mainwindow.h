#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QProcess>
#include "qmenubar.h"
#include "qfiledialog.h"
#include "qfile.h"
#include "qdebug.h"
#include "qtextstream.h"
#include "qstring.h"
#include "qdir.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    QString file1_path;
    QString file2_path;
    QFileInfo *fileinfo;
    int listsize;

    void commentdetect(QString,QString);
    void compareline(QString,QString,int);
private slots:
    void on_choose1btn_clicked();

    void on_choose2btn_clicked();

    void on_comparebtn_clicked();

    void on_pushButton_clicked();

    void gettoken();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
